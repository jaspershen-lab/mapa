library(r4projects)
library(tidyverse)

setwd(get_project_wd())
setwd("demo_data/covid_data//")

rm(list = ls())


load("transcriptome_data.RData")

transcriptome_data %>%
  extract_variable_info()

covid_data <-
  transcriptome_data %>%
  activate_mass_dataset(what = "variable_info") %>%
  dplyr::select(
    variable_id:ENSEMBL,
    ENTREZID:length,
    fc_ctrl_ba52,
    p_value_ctrl_ba52,
    p_value_adjust_ctrl_ba52
  ) %>%
  dplyr::rename(fc = fc_ctrl_ba52,
                p_value = p_value_ctrl_ba52,
                p_value_adjust = p_value_adjust_ctrl_ba52)

variable_info <-
  covid_data@variable_info

variable_info$fc[variable_info$fc == 0] <-
  min(variable_info$fc[variable_info$fc != 0])

covid_data@variable_info <-
  variable_info

save(covid_data, file = "covid_data.RData")
