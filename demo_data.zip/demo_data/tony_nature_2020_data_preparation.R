# library(r4projects)
# library(tidyverse)
#
# setwd(get_project_wd())
# setwd("demo_data/tony_wyss_cory_nature2020/")
#
# rm(list = ls())
#
# library(GEOquery)
#
# ###download expression data
# gse_matrix <- getGEO("GSE132040", GSEMatrix = TRUE)
#
# length(gse_matrix)
#
# expression_data <- exprs(gse_matrix[[1]])
#
# # 查看表达矩阵
# head(expr_data)
#
# # 保存表达矩阵到文件
# write.csv(expr_data, "expression_matrix.csv")
#
#
# gse <- getGEO("GSE132040", GSEMatrix = FALSE)
#
#
#
# ###get sample information
# samples <- pData(phenoData(gse[[1]]))
#
#
# load("expression_data")
# load("sample_info")
# load("variable_info")
#
# load("marker")
#
# colnames(expression_data)
#
# sample_info <-
#   sample_info %>%
#   dplyr::select(sample_id, subject_id2, g_stage, postdelivery, ga_range, class) %>%
#   dplyr::rename(subject_id = subject_id2) %>%
#   dplyr::filter(!postdelivery) %>%
#   dplyr::rename(time = g_stage, time_range = ga_range) %>%
#   dplyr::select(-postdelivery)
#
# expression_data <-
#   expression_data[, sample_info$sample_id]
#
# sample_info <-
#   sample_info %>%
#   dplyr::mutate(sample_id = paste(subject_id, time, sep = "_"))
#
# colnames(expression_data) <-
#   sample_info$sample_id
#
# variable_info <-
#   marker %>%
#   dplyr::select(variable_id,
#                 score,
#                 fdr,
#                 class,
#                 symbol,
#                 ensembl,
#                 alias,
#                 uniprot,
#                 entrezid)
#
#
# rownames(expression_data) == variable_info$variable_id
#
# expression_data <-
#   expression_data[variable_info$variable_id, ]
#
# new_expression_data <-
#   sample_info$time_range %>%
#   unique() %>%
#   sort() %>%
#   purrr::map(function(x) {
#     expression_data[, which(sample_info$time_range == x)] %>%
#       apply(1, mean)
#   }) %>%
#   do.call(cbind, .) %>%
#   as.data.frame()
#
# colnames(new_expression_data) <-
#   sample_info$time_range %>%
#   unique() %>%
#   sort()
#
# new_sample_info <-
#   sample_info %>%
#   dplyr::select(time_range, class) %>%
#   dplyr::distinct(time_range, .keep_all = TRUE) %>%
#   dplyr::arrange(time_range) %>%
#   dplyr::rename(sample_id = time_range)
#
#
# new_variable_info <-
#   variable_info %>%
#   dplyr::select(-alias)
#
#
# library(massdataset)
#
# demo_data <-
#   create_mass_dataset(
#     expression_data = new_expression_data,
#     sample_info = new_sample_info,
#     variable_info = new_variable_info
#   )
#
# save(demo_data, file = "demo_data.rda")
